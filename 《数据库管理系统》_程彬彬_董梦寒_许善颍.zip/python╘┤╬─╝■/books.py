# -*- coding: utf-8 -*-
"""图书管理"""
from db import get_db, audit

def search_books():
    """检索图书：按书名/ISBN/类别"""
    print("\n--- 图书检索 ---")
    kw = input("输入书名/ISBN/类别关键词：").strip()
    db = get_db()
    cond = {"$or": [
        {"title": {"$regex": kw, "$options": "i"}},
        {"isbn": {"$regex": kw, "$options": "i"}},
        {"category": {"$regex": kw, "$options": "i"}}
    ]}
    results = list(db.books.find(cond).limit(10))
    print(f"找到 {len(results)} 本：")
    for b in results:
        print(f"  {b.get('isbn')} | {b.get('title')} | {b.get('category')} | ¥{b.get('price')}")
    audit("search_books", f"关键词={kw}, 结果={len(results)}")

def add_book():
    """新增图书"""
    print("\n--- 新增图书 ---")
    isbn = input("ISBN：").strip()
    title = input("书名：").strip()
    category = input("类别：").strip()
    price = float(input("价格：").strip())
    db = get_db()
    try:
        db.books.insert_one({
            "isbn": isbn, "title": title, "category": category,
            "price": price, "stock": 1, "rating": 0.0
        })
        print(f"《{title}》添加成功")
        audit("add_book", f"ISBN={isbn}, 书名={title}")
    except Exception as e:
        print(f"添加失败：{e}")

def delete_book():
    """删除图书"""
    print("\n--- 删除图书 ---")
    isbn = input("要删除的ISBN：").strip()
    db = get_db()
    r = db.books.delete_one({"isbn": isbn})
    if r.deleted_count:
        print(f"已删除 ISBN={isbn}")
        audit("delete_book", f"ISBN={isbn}")
    else:
        print("未找到该图书")