# -*- coding: utf-8 -*-
"""借阅管理"""
from datetime import datetime
from db import get_db, audit

def borrow_book():
    print("\n--- 借书登记 ---")
    card = input("读者卡号：").strip()
    isbn = input("图书ISBN：").strip()
    db = get_db()
    log = {
        "reader_card": card, "book_isbn": isbn,
        "borrow_date": datetime.now(), "due_date": None, "status": "借出"
    }
    db.borrow_logs.insert_one(log)
    print("借书登记成功")
    audit("borrow", f"读者={card}, ISBN={isbn}")

def return_book():
    print("\n--- 还书登记 ---")
    card = input("读者卡号：").strip()
    isbn = input("图书ISBN：").strip()
    db = get_db()
    r = db.borrow_logs.update_one(
        {"reader_card": card, "book_isbn": isbn, "status": "借出"},
        {"$set": {"status": "已还", "return_date": datetime.now()}}
    )
    if r.modified_count:
        print("还书成功")
        audit("return", f"读者={card}, ISBN={isbn}")
    else:
        print("未找到借出记录")