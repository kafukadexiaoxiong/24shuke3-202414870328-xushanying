# -*- coding: utf-8 -*-
"""数据导入：建库建集 + 导入三份文件 + 核对数量"""
import json
import datetime
from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017/")
db = client["library"]

# 日期字段统一转换：兼容 {"$date": ...} 和 ISO 字符串两种格式
DATE_FIELDS = {"publish_date", "register_date", "borrow_date", "return_date"}

def parse_doc(doc):
    out = {}
    for k, v in doc.items():
        if isinstance(v, dict) and "$date" in v:
            out[k] = datetime.datetime.fromisoformat(v["$date"])
        elif k in DATE_FIELDS and isinstance(v, str):
            out[k] = datetime.datetime.fromisoformat(v)
        else:
            out[k] = v
    return out

def load(path):
    with open(path, encoding="utf-8") as f:
        return [parse_doc(d) for d in json.load(f)]

# 重新导入前清空旧数据（保证干净）
for col in ["books", "readers", "borrow_logs", "audit_logs", "category_stats"]:
    db.drop_collection(col)

books = load("books.txt")
readers = load("readers.txt")
borrow_logs = load("borrow_logs.txt")

db.books.insert_many(books)
db.readers.insert_many(readers)
db.borrow_logs.insert_many(borrow_logs)

# 核对数量
print("源文件条目数：books=%d, readers=%d, borrow_logs=%d" % (len(books), len(readers), len(borrow_logs)))
print("库中数量：books=%d, readers=%d, borrow_logs=%d" % (
    db.books.count_documents({}),
    db.readers.count_documents({}),
    db.borrow_logs.count_documents({})))
