# -*- coding: utf-8 -*-
"""数据库连接与操作日志"""
from pymongo import MongoClient
from datetime import datetime

_client = None

def get_db():
    global _client
    if _client is None:
        _client = MongoClient("mongodb://rw_user:rw123@localhost:27017/library")
    return _client["library"]

def audit(action, detail):
    """写操作日志"""
    db = get_db()
    db.audit_logs.insert_one({
        "action": action,
        "detail": detail,
        "time": datetime.now()
    })