# -*- coding: utf-8 -*-
"""智慧图书馆数字资源平台 - 主程序"""
from books import search_books, add_book, delete_book
from readers import search_reader, add_reader
from borrow import borrow_book, return_book
from stats import category_stats, hot_books, borrow_summary
from gridfs_utils import upload_all, list_files, download_by_title

MENU = """
===== 智慧图书馆数字资源平台 =====
1. 检索图书
2. 新增图书
3. 删除图书
4. 查询读者
5. 新增读者
6. 借书登记
7. 还书登记
8. 各类别图书统计
9. 热门图书Top5
10. 借阅总览
11. 上传电子书到GridFS
12. 列出GridFS文件
13. 下载电子书
0. 退出
==================================
"""

def main():
    actions = {
        "1": search_books, "2": add_book, "3": delete_book,
        "4": search_reader, "5": add_reader,
        "6": borrow_book, "7": return_book,
        "8": category_stats, "9": hot_books, "10": borrow_summary,
        "11": upload_all, "12": list_files, "13": download_by_title,
    }
    while True:
        print(MENU)
        choice = input("请选择功能：").strip()
        if choice == "0":
            print("再见！")
            break
        fn = actions.get(choice)
        if fn:
            try:
                fn()
            except Exception as e:
                print(f"出错了：{e}")
        else:
            print("无效选项")

if __name__ == "__main__":
    main()