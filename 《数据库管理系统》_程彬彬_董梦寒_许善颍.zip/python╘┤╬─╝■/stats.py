# -*- coding: utf-8 -*-
"""统计分析"""
from db import get_db, audit

def category_stats():
    print("\n--- 各类别图书数量统计 ---")
    db = get_db()
    for c in db.books.aggregate([
        {"$group": {"_id": "$category", "count": {"$sum": 1}, "avg_price": {"$avg": "$price"}}},
        {"$sort": {"count": -1}}
    ]):
        print(f"  {c['_id']}：{c['count']}本，均价¥{c['avg_price']:.1f}")

def hot_books():
    print("\n--- 热门图书 Top5 ---")
    db = get_db()
    for b in db.borrow_logs.aggregate([
        {"$group": {"_id": "$book_isbn", "cnt": {"$sum": 1}}},
        {"$sort": {"cnt": -1}}, {"$limit": 5}
    ]):
        book = db.books.find_one({"isbn": b["_id"]})
        title = book["title"] if book else b["_id"]
        print(f"  《{title}》 借阅{b['cnt']}次")

def borrow_summary():
    print("\n--- 借阅总览 ---")
    db = get_db()
    total = db.borrow_logs.count_documents({})
    borrowed = db.borrow_logs.count_documents({"status": "借出"})
    print(f"  总借阅记录：{total}")
    print(f"  当前借出：{borrowed}")
    audit("export_stats", f"总记录={total}, 借出={borrowed}")