# -*- coding: utf-8 -*-
"""GridFS 电子书与封面存储"""
import gridfs
import os
from db import get_db, audit

FILES_TO_UPLOAD = [
    (r"D:\Project\ebook_files\计算机网络.pdf",                    "9787111642637", "pdf",   "计算机网络（第8版）"),
    (r"D:\Project\ebook_files\cd组 计算机组装与维护实训报告.pdf",  "9787115546081", "pdf",   "计算机组装与维护"),
    (r"D:\Project\ebook_files\汤圆 (2).pdf",                     "9787115428028", "pdf",   "Python编程：从入门到实践"),
    (r"D:\Project\ebook_files\ty.jpg",        "9787111642637", "cover", "计算机网络（第8版）"),
    (r"D:\Project\ebook_files\tybaby.jpg",   "9787115546081", "cover", "计算机组装与维护"),
    (r"D:\Project\ebook_files\window.jpg",    "9787115428028", "cover", "Python编程：从入门到实践"),
]

def upload_all():
    db = get_db()
    fs = gridfs.GridFS(db)
    print("开始上传文件...")
    for path, isbn, ftype, title in FILES_TO_UPLOAD:
        if not os.path.exists(path):
            print(f"  跳过（文件不存在）：{path}")
            continue
        with open(path, "rb") as f:
            data = f.read()
        fname = os.path.basename(path)
        fid = fs.put(data, filename=fname, isbn=isbn, file_type=ftype, title=title)
        print(f"  上传成功：{fname} ({len(data)}字节) -> {title} [{ftype}]")
        audit("gridfs_upload", f"{fname} -> {title} [{ftype}], {len(data)}字节")
    print("上传完成")

def list_files():
    db = get_db()
    fs = gridfs.GridFS(db)
    print("\n--- GridFS 文件列表 ---")
    for f in fs.find():
        t = f.uploadDate.strftime("%Y-%m-%d %H:%M") if f.uploadDate else "N/A"
        print(f"  {f.filename:40s} | {f.length:>8d}字节 | {t} | {f.title} [{f.file_type}]")

def download_by_title():
    db = get_db()
    fs = gridfs.GridFS(db)
    print("\n--- 下载电子书 ---")
    title = input("输入书名关键词：").strip()
    results = list(fs.find({"title": {"$regex": title, "$options": "i"}, "file_type": "pdf"}))
    if not results:
        print("未找到相关电子书")
        return
    for i, f in enumerate(results):
        print(f"  [{i+1}] {f.title} ({f.length}字节)")
    idx = int(input("选择序号：").strip()) - 1
    f = results[idx]
    out_path = os.path.join(r"D:\Project", f.filename)
    with open(out_path, "wb") as out:
        out.write(f.read())
    local_size = os.path.getsize(out_path)
    match = "一致" if local_size == f.length else "不一致！"
    print(f"已下载到：{out_path}")
    print(f"上传时 {f.length} 字节，下载后 {local_size} 字节 → {match}")
    audit("gridfs_download", f"{f.filename}, {local_size}字节, 校验={match}")