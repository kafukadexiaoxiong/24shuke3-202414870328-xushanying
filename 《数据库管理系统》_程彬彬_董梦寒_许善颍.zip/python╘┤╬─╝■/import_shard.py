# -*- coding: utf-8 -*-
from pymongo import MongoClient
import json

c = MongoClient("mongodb://localhost:27023")
db = c["library"]

with open(r"D:\Project\borrow_logs.txt", encoding="utf-8") as f:
    data = json.load(f)

db.borrow_logs.insert_many(data)
print(f"导入了 {len(data)} 条borrow_logs")
print(f"当前总数：{db.borrow_logs.count_documents({})}")