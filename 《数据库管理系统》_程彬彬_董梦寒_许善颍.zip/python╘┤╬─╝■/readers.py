# -*- coding: utf-8 -*-
"""读者管理"""
from db import get_db, audit

def search_reader():
    print("\n--- 读者查询 ---")
    kw = input("输入卡号/姓名：").strip()
    db = get_db()
    cond = {"$or": [
        {"card_no": {"$regex": kw, "$options": "i"}},
        {"name": {"$regex": kw, "$options": "i"}}
    ]}
    for r in db.readers.find(cond).limit(10):
        print(f"  {r.get('card_no')} | {r.get('name')} | {r.get('dept')} | {r.get('type')}")

def add_reader():
    print("\n--- 新增读者 ---")
    card = input("卡号：").strip()
    name = input("姓名：").strip()
    dept = input("院系：").strip()
    db = get_db()
    try:
        db.readers.insert_one({"card_no": card, "name": name, "dept": dept, "type": "学生"})
        print(f"读者 {name} 添加成功")
        audit("add_reader", f"卡号={card}, 姓名={name}")
    except Exception as e:
        print(f"添加失败：{e}")